const CACHE_NAME = 'cashtop-pwa-v87-firebase-tooo-ee95f';
const FONT_CACHE_NAME = 'cashtop-font-cache-v87-firebase-tooo-ee95f';
const FONT_CSS_URL = 'https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap';
const PRECACHE = [
  './',
  'index.html',
  'login.html',
  'dashboard.html',
  'cashier.html',
  'customers.html',
  'accounts.html',
  'suppliers.html',
  'products.html',
  'workers.html',
  'warehouse.html',
  'purchases.html',
  'invoices.html',
  'expenses.html',
  'inventory.html',
  'finance.html',
  'analytics.html',
  'notifications.html',
  'mobile-scanner.html',
  'employees.html',
  'settings.html',
  'manifest.json',
  'sw.js',
  'README.md',
  'DATABASE_STRUCTURE.md',
  'firestore.rules',
  'database.rules.json',
  'firestore.secure.rules',
  'icon-64.png',
  'icon-192.png',
  'icon-512.png',
  'oscar-logo.png',



  'app-version.json',
  'offline-update.js',
  'local-bridge.js'
];


async function cacheCairoFont() {
  try {
    const cache = await caches.open(FONT_CACHE_NAME);
    const cssReq = new Request(FONT_CSS_URL, {mode:'cors', cache:'reload'});
    const cssRes = await fetch(cssReq);
    if(cssRes && cssRes.ok) {
      await cache.put(cssReq, cssRes.clone());
      const cssText = await cssRes.clone().text();
      const fontUrls = [...cssText.matchAll(/url\((https:\/\/fonts\.gstatic\.com\/[^)]+)\)/g)].map(m => m[1]);
      await Promise.allSettled(fontUrls.map(async src => {
        const req = new Request(src, {mode:'cors', cache:'reload'});
        const res = await fetch(req);
        if(res && res.ok) await cache.put(req, res.clone());
      }));
    }
  } catch(e) {}
}

async function fontCacheFirst(req) {
  const cache = await caches.open(FONT_CACHE_NAME);
  const hit = await cache.match(req, {ignoreSearch:false});
  if(hit) {
    fetch(req).then(res => {
      if(res && res.ok) cache.put(req, res.clone());
    }).catch(()=>null);
    return hit;
  }
  const res = await fetch(req);
  if(res && res.ok) await cache.put(req, res.clone());
  return res;
}

async function cacheOne(cache, url) {
  try {
    const req = new Request(url, {cache:'reload'});
    const res = await fetch(req);
    if(res && res.ok) await cache.put(req, res.clone());
  } catch(e) {}
}

self.addEventListener('install', event => {
  self.skipWaiting();
  event.waitUntil((async()=>{
    const cache = await caches.open(CACHE_NAME);
    await Promise.allSettled(PRECACHE.map(u => cacheOne(cache, u)));
    await cacheCairoFont();
  })());
});

self.addEventListener('activate', event => {
  event.waitUntil((async()=>{
    const keys = await caches.keys();
    await Promise.all(keys.filter(k => ![CACHE_NAME, FONT_CACHE_NAME].includes(k)).map(k => caches.delete(k)));
    await self.clients.claim();
  })());
});

async function cached(req) {
  return await caches.match(req, {ignoreSearch:true}) || await caches.match('./index.html', {ignoreSearch:true});
}

async function putFresh(req) {
  const res = await fetch(req, {cache:'no-store'});
  if(res && res.ok) {
    const cache = await caches.open(CACHE_NAME);
    await cache.put(req, res.clone());
  }
  return res;
}


self.addEventListener('fetch', event => {
  const req = event.request;
  if(req.method !== 'GET') return;
  const url = new URL(req.url);

  if(url.hostname === 'fonts.googleapis.com' || url.hostname === 'fonts.gstatic.com') {
    event.respondWith(fontCacheFirst(req));
    return;
  }

  // لا نلمس Firebase أو أي طلب خارجي حتى لا تتأثر المزامنة.
  if(url.origin !== self.location.origin) return;

  const isNavigation = req.mode === 'navigate' || (req.headers.get('accept') || '').includes('text/html');

  async function cacheFirst(){
    const cache = await caches.open(CACHE_NAME);
    const pageName = url.pathname.split('/').pop() || 'index.html';
    const hit =
      await cache.match(req, {ignoreSearch:true}) ||
      await caches.match(req, {ignoreSearch:true}) ||
      (isNavigation ? await cache.match(pageName, {ignoreSearch:true}) : null) ||
      (isNavigation ? await cache.match('index.html', {ignoreSearch:true}) : null);

    if(hit) return hit;

    // أول مرة فقط: إذا الملف غير موجود بالكاش نحمله ونخزنه.
    try{
      const fresh = await fetch(req);
      if(fresh && fresh.ok) await cache.put(req, fresh.clone());
      return fresh;
    }catch(e){
      return (await cache.match('index.html', {ignoreSearch:true})) || Response.error();
    }
  }

  event.respondWith(cacheFirst());
});

self.addEventListener('message', event => {
  if(event.data && event.data.type === 'SKIP_WAITING') self.skipWaiting();
});
